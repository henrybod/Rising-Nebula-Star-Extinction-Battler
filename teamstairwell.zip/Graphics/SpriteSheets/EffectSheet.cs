﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace Hook.Graphics.SpriteSheets
{
    public class EffectSheet : SpriteSheet
    {
        public const int BLOODFOUNTAIN = 0;

        public EffectSheet(Texture2D SheetImage)
            : base()
        {
            this.SheetImage = SheetImage;

            FrameValues = new int[,]{
                {228, 105, 13} //BLOOOOOOD
            };
        }
    }
}
