﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace Hook.Graphics.SpriteSheets
{
    public class PanelSheet : SpriteSheet
    {
        public const int BUTTONFRAME = 0;

        public PanelSheet(Texture2D SheetImage)
            : base()
        {
            this.SheetImage = SheetImage;

            FrameValues = new int[,]{
                {200, 100, 1}   //ButtonFrame
            };
        }
    }
}
