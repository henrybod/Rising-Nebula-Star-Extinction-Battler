﻿#region Using Statements
using System;
using System.Collections.Generic;
//using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
//using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using Hook.Graphics;
using Hook.Graphics.SpriteSheets;
#endregion

namespace teamstairwell
{
    class Player : Entity
    {
        public Player(Vector2 position, Vector2 velocity, Vector2 acceleration, float radius)
            : base(position, velocity, acceleration, radius)
        { 
        }

        public void update(GameTime time, List<Bullet> lst)
        {
            Console.WriteLine(pos);
            KeyboardState state = Keyboard.GetState();

            if (state.IsKeyDown(Keys.Up) && state.IsKeyUp(Keys.Down))
            {
                vel.Y = -10;
            }
            else if (state.IsKeyDown(Keys.Down) && state.IsKeyUp(Keys.Up))
            {
                vel.Y = 10;
            }
            else
                vel.Y = 0;

            if (state.IsKeyDown(Keys.Left) && state.IsKeyUp(Keys.Right))
            {
                vel.X = -10;
            }
            else if (state.IsKeyDown(Keys.Right) && state.IsKeyUp(Keys.Left))
            {
                vel.X = 10;
            }
            else
                vel.X = 0;

            if (state.IsKeyDown(Keys.LeftShift) || state.IsKeyDown(Keys.RightShift))
            {
                vel = vel / 2;
            }

            if (state.IsKeyDown(Keys.Z))
            {
                Bullet b = new Bullet(pos, new Vector2(0, -50), Vector2.Zero, 0f, new Sprite(Game1.PropSheet, PropSheet.GUM1));
                lst.Add(b);
                //shoot
            }

            if (state.IsKeyDown(Keys.X))
            {
                //bomb
            }
            base.update(time);
        }

        /*public override void draw()
        {
        }*/
    }
}