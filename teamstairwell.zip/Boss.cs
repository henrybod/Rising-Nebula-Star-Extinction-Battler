﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Hook.Graphics;
using Hook.Graphics.SpriteSheets;

namespace teamstairwell
{
    class Boss : Entity
    {
        List<BulletSpawner> lst;
        TimeSpan spawnRate = new TimeSpan(0, 0, 0, 0, 500);
        TimeSpan spawnTime = TimeSpan.Zero;

        public Boss(Vector2 position, Vector2 velocity, Vector2 acceleration, float radius, List<BulletSpawner> spawnerList)
            : base(position, velocity, acceleration, radius)
        {
            lst = spawnerList;
        }

        public override void update(GameTime gt)
        {
            // we're fighting our way through a gumball machine

            //Console.WriteLine("BOSS" + pos);
            if (pos.X < -550)
            {
                vel.X = 7;
            }
            else if (pos.X > 550)
            {
                vel.X = -7;
            }

            spawn(gt);
            base.update(gt);
        }

        public void spawn(GameTime gt)
        {
            if (gt.TotalGameTime - spawnTime > spawnRate)
            {
                Random r = new Random();
                int chooser = r.Next() % 2;
                switch (chooser)
                {
                    case 0:
                        //blah;
                        break;
                    case 1:
                        //lst.Add(new BurstSpawner(Vector2.Zero, Vector2.Zero, Vector2.Zero, 1, 0, .25f, bul, false, 20));
                        break;
                }

                //lst.Add(new BulletSpawner(pos, new Vector2(0, 5), Vector2.Zero, 0f, new Sprite(Game1.PlayerSheet, PlayerSheet.GROUNDIDLE), 0f, 0f));
                spawnTime = gt.TotalGameTime;
            }
 
        }
    }
}
