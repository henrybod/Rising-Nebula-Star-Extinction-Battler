﻿#region Using Statements
using System;
using System.Collections.Generic;
//using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
//using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using Hook.Graphics;
using Hook.Graphics.SpriteSheets;
#endregion

namespace teamstairwell
{
    class Entity
    {
        internal Vector2 pos;
        internal Vector2 vel;
        internal Vector2 acc;
        internal float rot;
        internal float hitrad;
        internal Sprite pic;

        public Entity()
        {
            pic = null;
            pos = Vector2.Zero;
            vel = Vector2.Zero;
            acc = Vector2.Zero;
            hitrad = 0;
        }

        public Entity(Vector2 position, Vector2 velocity, Vector2 acceleration, float radius)
        {
            pos = position;
            vel = velocity;
            acc = acceleration;
            hitrad = radius;

            pic = new Sprite(Game1.PlayerSheet, PlayerSheet.P0);
        }

        public virtual void update(GameTime gt)
        {
            vel += acc;
            pos += vel;
            pic.Update(gt);
            pic.Position.X = pos.X;
            pic.Position.Y = pos.Y;
            pic.Rotation.Z = rot;
        }

        public void draw(SpriteBatch sb)
        {
            pic.Draw(sb);
        }
    }
}
