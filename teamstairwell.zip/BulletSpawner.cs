﻿#region Using Statements
using System;
using System.Collections.Generic;
//using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
//using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using Hook.Graphics;
using Hook.Graphics.SpriteSheets;
#endregion


namespace teamstairwell
{
    class BulletSpawner : Entity
    {
        float rvel;
        internal Boolean doRetract;
        internal List<Bullet> bBs;
        double timer;

        public BulletSpawner(Vector2 position, Vector2 velocity, Vector2 acceleration, float radius, float rotation, float rotationVelocity, List<Bullet> bossBullets, Boolean retract)
            : base(position, velocity, acceleration, radius)
        {
            rot = rotation;
            doRetract = retract;
            rvel = rotationVelocity;
            bBs = bossBullets;
            timer = 0;

            pic = new Sprite(Game1.PlayerSheet, PlayerSheet.BOSS);
        }

        public virtual void SpawnB()
        {
            float vx = (float)Math.Cos(rot);
            float vy = (float)Math.Sin(rot);

            float ax = 0;
            float ay = 0;
            if (doRetract)
            {
                ax = -.005f * vx;
                ay = -.005f * vy;
            }
            bBs.Add(new Bullet(pos, new Vector2(2 * vx, 2 * vy), new Vector2(ax, ay), 7.5f, new Sprite(Game1.PropSheet, PropSheet.GUM1)));
            //lst.Add(new Bullet(pos, new Vector2(0, 2), Vector2.Zero, 7.5f, new Sprite(Game1.PropSheet, PropSheet.THICKLINK)));
        }

        public override void update(GameTime gt)
        {
            timer -= gt.ElapsedGameTime.TotalSeconds;
            if (timer <= 0)
            {
                SpawnB();
                timer = .5;
            }

            rot += rvel;
            base.update(gt);
        }
    }
}
